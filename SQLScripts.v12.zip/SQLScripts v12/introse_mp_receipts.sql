-- MySQL dump 10.13  Distrib 5.7.9, for Win64 (x86_64)
--
-- Host: localhost    Database: introse_mp
-- ------------------------------------------------------
-- Server version	5.6.27-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `receipts`
--

DROP TABLE IF EXISTS `receipts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `receipts` (
  `receiptID` int(11) NOT NULL AUTO_INCREMENT,
  `sold_price` double NOT NULL,
  `sold_quantity` int(11) NOT NULL,
  `sold_date` date NOT NULL,
  `customer_name` varchar(45) NOT NULL,
  `sold_branch` int(11) NOT NULL,
  `staffName` varchar(45) NOT NULL,
  `sold_ProductName` varchar(45) NOT NULL,
  PRIMARY KEY (`receiptID`)
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `receipts`
--

LOCK TABLES `receipts` WRITE;
/*!40000 ALTER TABLE `receipts` DISABLE KEYS */;
INSERT INTO `receipts` VALUES (4,5000,2,'2016-03-05','Glenn',1,'Glenn','cat'),(5,1,2,'2016-03-05','Driggs',1,'Driggs','phone'),(6,200,1,'2016-03-05','GLenn',1,'GLenn','chair'),(7,2,1,'2016-03-05','wala',1,'wala','Roshe'),(8,2,2,'2016-03-05','md',1,'me','Roshe'),(9,2,3,'2016-03-05','me',1,'me','Roshe'),(10,3,2,'2016-03-05','mw',1,'mw','Roshe'),(11,100,5,'2016-03-05','me',1,'me','Blouse'),(12,2,1,'2016-03-05','me',1,'10','Roshe'),(13,2,1,'2016-03-05','glenn',1,'1000','Roshe'),(14,2,5,'2016-03-05','matias',1,'2','Blouse'),(15,20,1,'2016-03-05','nanay mo',1,'nene','Blouse'),(16,2,1,'2016-03-05','a',1,'b','Blouse'),(17,2,3,'2016-03-05','b',1,'b','Blouse'),(18,1000000,4,'2016-03-05','Carvin',1,'Chester','Blouse'),(19,0,3,'2016-03-05','-9',1,'myfrend','Roshe'),(20,-9,495,'2016-03-05','ii',1,'o','Roshe'),(21,67,2,'2016-03-05','uu',1,'t','Roshe'),(22,40,2,'2016-03-05','wala',1,'1','Blouse'),(23,2000,95,'2016-03-05','Glenn',1,'Chester','Roshe'),(24,2,1,'2016-03-05','me',1,'2','Roshe');
/*!40000 ALTER TABLE `receipts` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2016-03-05 16:23:15
