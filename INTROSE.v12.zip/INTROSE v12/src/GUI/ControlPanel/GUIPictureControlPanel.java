package GUI.ControlPanel;

import javax.swing.JPanel;
import javax.swing.JLabel;
import javax.swing.JButton;
import java.awt.Font;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import net.miginfocom.swing.MigLayout;

public class GUIPictureControlPanel implements ActionListener{
	
	private JPanel jPanel = new JPanel();
	private JLabel lblPicturePanel = new JLabel("Picture Preview");
	
	public GUIPictureControlPanel(){
		
		jPanel.setSize(150,450);
		jPanel.setLayout(null);
		
		lblPicturePanel.setBounds(7, 7, 84, 23);
		lblPicturePanel.setFont(new Font("Tahoma", Font.PLAIN, 19));
		jPanel.add(lblPicturePanel);

	}
	public JPanel getJPanel() {
		return jPanel;
	}
	
	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		
	}
}
