
public class ProductType {
	private int productTypeID;
	private String productTypeName;
	
	
	public ProductType(String productTypeName)
	{
		this.productTypeName = productTypeName;
	}
	
	public int getProductTypeId()
	{
		return productTypeID;
	}
	
	public String getProductTypeName()
	{
		return productTypeName;
	}
}


