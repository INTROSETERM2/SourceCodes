import javax.swing.*;

public class MainGUI extends JFrame{
	JLabel leftLabel = new JLabel();
	JLabel rightLabel = new JLabel();
	
	JSplitPane splitPane = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT, new JScrollPane(leftLabel),new JScrollPane(rightLabel));
	
	public MainGUI(){
		Login login = new Login();
		POSReceipt posReceipt = new POSReceipt();
		GUIControlPanel guiControlPanel = new GUIControlPanel();
		splitPane.setEnabled(false);//
		splitPane.setResizeWeight(.2d);
		leftLabel.add(guiControlPanel.getJPanel());
		rightLabel.add(posReceipt.getJPanel());
		add(splitPane);
	}
	
	public static void main(String[] args) {
		MainGUI sp = new MainGUI();
		sp.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		sp.setSize(1000,500);
		sp.setVisible(true);
	}
}