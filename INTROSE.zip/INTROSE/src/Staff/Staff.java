package Staff;
import java.text.SimpleDateFormat;

import Branch.Branch;
import DB.DBConnect;

public class Staff {
	
	private int staffID;
	private String userName;
	private String password;
	private String firstname;
	private String lastname;
	private static Boolean RANK;
	private Branch branch;
	private SimpleDateFormat creationDate;
	private DBConnect db = new DBConnect();
	
	public Staff() {
		// TODO Auto-generated constructor stub
	}
	
	public int getStaffID()
	{
		return staffID;
	}
	
	public String getUsername()
	{
		return userName;
	}
	
	public String getPassword()
	{
		return password;
	}

	public String getFirstname()
	{
		return firstname;
	}

	public String getLastname()
	{
		return lastname;
	}
	
	public Boolean getRank()
	{
		return RANK;
	}
	
	public Branch getBranch()
	{
		return branch;
		
	}
	
	public SimpleDateFormat getCreationDate()
	{
		return creationDate;
	}

}

