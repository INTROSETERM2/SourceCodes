import javax.swing.JPanel;
import javax.swing.JLabel;
import javax.swing.JButton;
import java.awt.Font;
import java.awt.GridBagLayout;
import java.awt.GridBagConstraints;
import java.awt.Insets;

public class GUIControlPanel {
	
	private JPanel jPanel = new JPanel();
	
	public GUIControlPanel()
	{
		jPanel.setSize(200,600);
		GridBagLayout gbl_jPanel = new GridBagLayout();
		gbl_jPanel.columnWidths = new int[]{168, 0};
		gbl_jPanel.rowHeights = new int[]{30, 23, 0, 0};
		gbl_jPanel.columnWeights = new double[]{1.0, Double.MIN_VALUE};
		gbl_jPanel.rowWeights = new double[]{0.0, 0.0, 0.0, Double.MIN_VALUE};
		jPanel.setLayout(gbl_jPanel);
		
		JLabel lblControlPanel = new JLabel("Control Panel");
		lblControlPanel.setFont(new Font("Tahoma", Font.PLAIN, 19));
		GridBagConstraints gbc_lblControlPanel = new GridBagConstraints();
		gbc_lblControlPanel.gridheight = 2;
		gbc_lblControlPanel.fill = GridBagConstraints.VERTICAL;
		gbc_lblControlPanel.anchor = GridBagConstraints.WEST;
		gbc_lblControlPanel.insets = new Insets(0, 0, 5, 0);
		gbc_lblControlPanel.gridx = 0;
		gbc_lblControlPanel.gridy = 0;
		jPanel.add(lblControlPanel, gbc_lblControlPanel);
		
		JButton btnAddSales = new JButton("Add Sales");
		GridBagConstraints gbc_btnAddSales = new GridBagConstraints();
		gbc_btnAddSales.fill = GridBagConstraints.HORIZONTAL;
		gbc_btnAddSales.anchor = GridBagConstraints.NORTH;
		gbc_btnAddSales.gridx = 0;
		gbc_btnAddSales.gridy = 2;
		jPanel.add(btnAddSales, gbc_btnAddSales);
	}
	public JPanel getJPanel() {
		return jPanel;
	}
}
