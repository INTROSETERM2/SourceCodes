import java.text.SimpleDateFormat;

public class TryCodeClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		DBConnect db = new DBConnect();
		
		//db.signup("new", "bootyeater", "new chester", "new gaw", 1, 0);
		//System.out.println(db.login("3d12", "chesterpass"));
		//db.addReceipt(1, 30, 2, "Your mom", 2);
	
		//db.deleteReceipt(1);
		
		//ProductType productType = new ProductType("Glenn");
		
	//	db.addProductType(productType);
		//db.deleteProductType(1);
	
	System.out.println(db.getNextAvailableProductTypeID());
	//	System.out.println(db.getPicture(1));
	
	Branch branch = new Branch(1, "168", 2);
	Receipt receipt = new Receipt(1, 2,2.0,1 ,getCurrentDate(), "glenn", branch, 2);
	

	public Receipt(int receiptID, int staffID, float soldPrice, int soldQuantity, SimpleDateFormat soldDate, String customerName, Branch soldBranch, int soldProductID)
	db.addReceipt(receipt);
	}

	
	private static java.sql.Date getCurrentDate() {
	    java.util.Date today = new java.util.Date();
	    return new java.sql.Date(today.getTime());
	}
}
	