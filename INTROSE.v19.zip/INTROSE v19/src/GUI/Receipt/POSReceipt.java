package GUI.Receipt;

import javax.swing.*;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;

import Branch.Branch;
import DB.DBConnect;
import GUI.MainGUI;
import GUI.ControlPanel.GUIPictureControlPanel;
import GUI.UserAccount.Login;
import Product.ManagerProduct;
import Receipt.Receipt;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;

import net.miginfocom.swing.MigLayout;

public class POSReceipt implements ActionListener {
	JPanel jPanel = new JPanel();
	DBConnect db = new DBConnect();

	// private JTable table = new JTable();
	private JTable table = new JTable();

	private JComboBox cmbItemName;
	private JComboBox cmbQuantity;
	private JTextField txtPrice = new JTextField();
	private JTextField txtStaff = new JTextField();
	private JTextField txtCustomer = new JTextField();

	private JLabel lblCustomer = new JLabel("Customer");
	private JLabel lblBranch = new JLabel("Branch:");
	private JLabel branchNumber = new JLabel(Integer.toString(MainGUI.BRANCH.getBranchID()));
	private JLabel lblTotalAmount = new JLabel("Total Amount");
	private JLabel lblDate = new JLabel("Date:");

	// for Date
	private DateFormat df = new SimpleDateFormat("MM/dd/yyyy");
	private Date today = Calendar.getInstance().getTime();
	private String currentDate = df.format(today);

	private JLabel lblDatenow = new JLabel(currentDate);
	private JLabel lblItemName = new JLabel("Item name");
	private JLabel lblQuantity = new JLabel("Quantity");
	private JLabel lblPrice = new JLabel("Price");
	private JLabel lblStaff = new JLabel("Staff");
	private JButton btnPreview = new JButton("Preview");
	private JButton btnAdd = new JButton("Add");
	private JLabel lblTotalAmountComputed = new JLabel(String.valueOf(db.getTotalSalesToday()) + " php");
	private MainGUI mainGUI;
	private JButton btnEdit = new JButton("Edit");
	
	public static ImageIcon IMAGE = null;
	private JLabel labelPicture = new JLabel("Select Picture");
	
	
	public POSReceipt(MainGUI mainGUI) {
		this.mainGUI = mainGUI;

		lblTotalAmountComputed.setForeground(Color.red);
		lblTotalAmountComputed.setBackground(Color.white);
		lblTotalAmountComputed.setOpaque(true);
		setTable();
		ActListener act = new ActListener();

		JScrollPane scrollPane = new JScrollPane();

		scrollPane.setViewportView(table);
		jPanel.setSize(580, 450);
		jPanel.setLayout(new MigLayout("",
				"[33px][12px][59px][grow][16px][71px][17px][74px][42px][64px][12px][89px][12px][85px]",
				"[20px][20px][218px][14px][23px][23px][]"));

		jPanel.add(lblTotalAmountComputed, "cell 11 0 3 1");

		jPanel.add(lblBranch, "cell 0 0,alignx right,aligny center");

		jPanel.add(branchNumber, "cell 2 0");

		jPanel.add(lblTotalAmount, "cell 9 0,alignx left,aligny center");

		jPanel.add(lblDate, "cell 0 1,alignx right,aligny center");

		jPanel.add(lblDatenow, "cell 2 1");

		jPanel.add(scrollPane, "cell 0 2 14 1,grow");

		jPanel.add(lblItemName, "cell 0 3,growx,aligny bottom");

		btnPreview.addActionListener(act);
		jPanel.add(btnPreview, "cell 2 3,growx,aligny top");

		jPanel.add(lblQuantity, "cell 3 3,alignx left,aligny bottom");

		jPanel.add(lblCustomer, "cell 7 3,aligny bottom");

		jPanel.add(lblPrice, "cell 9 3,alignx left,aligny bottom");

		jPanel.add(lblStaff, "cell 13 3,alignx left,aligny bottom");
		cmbItemName = new JComboBox(db.getProducts().toArray());
		cmbItemName.addActionListener(act);
		jPanel.add(cmbItemName, "cell 0 4 3 1,growx,aligny center");

		cmbQuantity = new JComboBox();
		cmbQuantity.addActionListener(act);

		jPanel.add(cmbQuantity, "cell 3 4 4 1,growx,aligny center");

		txtCustomer.setColumns(10);
		jPanel.add(txtCustomer, "cell 7 4 2 1,growx");

		jPanel.add(txtPrice, "cell 9 4 3 1,growx,aligny center");
		txtPrice.setColumns(10);

		jPanel.add(txtStaff, "cell 13 4,alignx left,aligny center");
		txtStaff.setColumns(10);

		btnAdd.addActionListener(act);
		


		
	
	      
	        

		jPanel.add(btnEdit, "cell 0 5 6 1,growx");
		jPanel.add(btnAdd, "cell 7 5 7 1,growx,aligny top");
		btnEdit.addActionListener(act);
		btnEdit.setEnabled(false);
		ListSelectionModel listSelectionModel = table.getSelectionModel();
		listSelectionModel.addListSelectionListener(new ListSelectionListener() {
		        public void valueChanged(ListSelectionEvent e) { 
		            ListSelectionModel lsm = (ListSelectionModel)e.getSource();
		            btnEdit.setEnabled(!lsm.isSelectionEmpty());
		}});
		
		table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
		
	}

	public JPanel getJPanel() {
		return jPanel;
	}

	public void setTable() {
		table = new JTable(db.retrieveDailySales());
		table.getTableHeader().setReorderingAllowed(false);

	}

	private class ActListener implements ActionListener {
		public void actionPerformed(ActionEvent a) {
			if (a.getSource() == cmbItemName) {
				DBConnect db = new DBConnect();

				cmbQuantity.removeAllItems();
				db.retrieveDailySales();

				ArrayList<String> quantityContent = new ArrayList<String>();
				

				String selectedItem = cmbItemName.getSelectedItem().toString();

				int i;
				
				for (i = 0; i < db.getQuantity(selectedItem); i++)
					quantityContent.add(Integer.toString(i + 1));

				cmbQuantity.insertItemAt("Select", 0);
				cmbQuantity.setSelectedIndex(0);

				for (i = 0; i < quantityContent.size(); i++)
					cmbQuantity.insertItemAt(quantityContent.get(i), i);
			}

			if(a.getSource() == btnEdit)
			{
				mainGUI.removeAllRightSplit();
					POSReceipt posReceipt = new POSReceipt(mainGUI);
					mainGUI.setRightSplit(posReceipt.getJPanel());
				
					int row = table.getSelectedRow();
					int column = table.getColumnCount();
					
					int receiptNumber = 0;
					String productName = "";
					double price = 0;
					int quantity = 0;
					String staff = "";
					
					receiptNumber =	Integer.parseInt((String) table.getValueAt(row, 0));
					productName =  (String) table.getValueAt(row, 1); 	
					price = new Double(table.getValueAt(row, 2).toString()); 
					quantity = Integer.parseInt((String) table.getValueAt(row, 3));
					staff = (String) table.getValueAt(row, 4);
					    
				    EditReceipt editReceipt = new EditReceipt(mainGUI, receiptNumber, productName, price, quantity, staff);
				

			}
			
			if(a.getSource() == btnPreview) {
				// Kung ano mangyayari kapag pinindot button
				GUIPictureControlPanel picControl = new GUIPictureControlPanel();
				String filePath = db.getPicture(db.getProductID(cmbItemName.getSelectedItem().toString()));
				if(filePath == "no"){
					JOptionPane.showMessageDialog(null, "No picture for selected product or no product selected!");
				}
				else{
					try{
						IMAGE = new ImageIcon(filePath);	
					}catch(Exception e){
						e.printStackTrace();
					}
				}
				mainGUI.removeAllLeftSplit();
				mainGUI.setLeftSplit();
			}
	
	

			if (a.getSource() == btnAdd) {
				// check if number o hindi

				boolean ret = true;
				try {
					Double.parseDouble(txtPrice.getText());
				} catch (final NumberFormatException e) {
					ret = false;
				}

				if (ret == false) {
					JOptionPane.showMessageDialog(null, "Please input numbers only on the price");
					txtPrice.setText("");
					txtStaff.setText("");
					txtCustomer.setText("");
					cmbItemName.setSelectedIndex(0);

					mainGUI.removeAllRightSplit();
					POSReceipt posReceipt = new POSReceipt(mainGUI);
					mainGUI.setRightSplit(posReceipt.getJPanel());
				} else if (Double.parseDouble(txtPrice.getText()) < 0) {
					JOptionPane.showMessageDialog(null, "Please input numbers not less than 0");
					mainGUI.removeAllRightSplit();
					POSReceipt posReceipt = new POSReceipt(mainGUI);
					mainGUI.setRightSplit(posReceipt.getJPanel());
				}

				if (txtPrice.getText() == "" || txtCustomer.getText() == "" || txtStaff.getText() == ""
						|| cmbItemName.getSelectedItem().toString() == "Select"
						|| cmbQuantity.getSelectedItem().toString() == "Select") {
					JOptionPane.showMessageDialog(null, "Please fill in all the data");
					txtPrice.setText("");
					txtStaff.setText("");
					txtCustomer.setText("");
					cmbItemName.setSelectedIndex(0);

				}

				else {
					table = new JTable();
					db.retrieveDailySales();

					jPanel.revalidate();
					jPanel.repaint();
					ManagerProduct managerProduct = new ManagerProduct();
					Receipt receipt = new Receipt(txtStaff.getText(), Double.parseDouble(txtPrice.getText()),
							Integer.parseInt(cmbQuantity.getSelectedItem().toString()), today, txtCustomer.getText(),
							MainGUI.BRANCH, 1, cmbItemName.getSelectedItem().toString());

					db.addReceipt(receipt);
					managerProduct.decrementProduct(cmbItemName.getSelectedItem().toString(),
							Integer.parseInt(cmbQuantity.getSelectedItem().toString()));

					mainGUI.removeAllRightSplit();
					POSReceipt posReceipt = new POSReceipt(mainGUI);
					mainGUI.setRightSplit(posReceipt.getJPanel());
				}
			}
			
			
		}
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub

	}

}